from django.contrib import admin
from .models import *

admin.site.register(Site_Settings)
admin.site.register(Maintenance_Cost)
admin.site.register(Daily_Profit)